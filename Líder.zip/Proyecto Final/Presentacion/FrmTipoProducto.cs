﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;
using Proyecto1.RN;
using Utilitarios;


namespace Presentacion
{
    public partial class FrmTipoProducto : Form
    {
        public FrmTipoProducto()
        {
            InitializeComponent();
        }

        private void limpiar()
        {
            //this.txbId.Text = "";
            this.txbTipo.Text = "";
            

            //this.txbBuscar.Text = "Todos";

            //this.cbEliminar.Checked = false;
            this.btnGuardar.Enabled = false;
            //this.btnEliminar.Enabled = false;
            //this.btnImprimir.Enabled = false;
            this.btnGuardar.Text = "Guardar";
        }

        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txbTipo_TextChanged(object sender, EventArgs e)
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            if (ObjRNTipoProducto.TraerTipoProductoPorTipo(this.txbTipo.Text).Count > 0)
            {
                this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProductoPorTipo(this.txbTipo.Text);
                this.btnGuardar.Enabled = false;
            }
            else
            {
                this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProductoPorTipo(this.txbTipo.Text);
                this.btnGuardar.Enabled = true;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            TipoProducto ObjTipoProducto = new TipoProducto();
            if (this.btnGuardar.Text == "Guardar")
            {
                ObjTipoProducto.idTipoProducto = Convert.ToInt32(ObjRNTipoProducto.GenerarId());
                ObjTipoProducto.tipo = this.txbTipo.Text;
                if (ObjRNTipoProducto.Insertar(ObjTipoProducto))
                {
                    MessageBox.Show("Tipo de producto insertado con exito");
                    this.txbCodigo.Text = ObjTipoProducto.idTipoProducto.ToString();
                    this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(ObjTipoProducto.idTipoProducto);
                    Utilitarios.Utilitarios.id = ObjTipoProducto.idTipoProducto;
                }
                else
                {
                    MessageBox.Show("Error en el registro de tipo de producto");
                }
            }
        }

        private void cbEliminar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbEliminar.Checked)
            {
                this.dgvTipo.Columns[0].Visible = true;
                this.btnEliminar.Enabled = true;
            }
            else
            {
                this.dgvTipo.Columns[0].Visible = false;
                this.btnEliminar.Enabled = false;
            }
        }

        private void txbBuscar_TextChanged(object sender, EventArgs e)
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            if (this.txbBuscar.Text == "Todos" || this.txbBuscar.Text == "")
            {
                this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(0);
            }
            else
            {
                int id;
                if (int.TryParse(this.txbBuscar.Text, out id))
                {
                    this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(id);
                }
                else
                {
                    this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProductoPorTipo(this.txbBuscar.Text);
                }
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            if (this.txbBuscar.Text == "Todos" || this.txbBuscar.Text == "")
            {
                this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(0);
            }
            else
            {
                int id;
                if (int.TryParse(this.txbBuscar.Text, out id))
                {
                    this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(id);
                }
                else
                {
                    this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProductoPorTipo(this.txbBuscar.Text);
                }
            }
        }

        private void dgvTipo_DoubleClick(object sender, EventArgs e)
        {
            this.txbCodigo.Text = Convert.ToString(this.dgvTipo.CurrentRow.Cells["ID"].Value);
            this.txbTipo.Text = Convert.ToString(this.dgvTipo.CurrentRow.Cells["Tipo"].Value);
            Utilitarios.Utilitarios.id = Convert.ToInt32(this.dgvTipo.CurrentRow.Cells["ID"].Value);
            this.btnGuardar.Text = "Actualizar";
        }

        private void dgvTipo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvTipo.Rows[e.RowIndex];
                int id = Convert.ToInt32(row.Cells[1].Value);

                Utilitarios.Utilitarios.id = id;
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            Utilitarios.Utilitarios.NroReporte = 2;
            FrmReportes ObjFrmReporte = new FrmReportes();
            ObjFrmReporte.Show();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            TipoProducto ObjTipoProducto = new TipoProducto();

            try
            {
                DialogResult Opcion;
                Opcion = MessageBox.Show("Está seguro que desea eliminar estos registros?", "Usuarios", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (Opcion == DialogResult.OK)
                {
                    Boolean Rpta = false;
                    foreach (DataGridViewRow row in dgvTipo.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            ObjTipoProducto.idTipoProducto = Convert.ToInt32(row.Cells[1].Value);
                            ObjTipoProducto.tipo = Convert.ToString(row.Cells[2].Value);
                            

                            Rpta = ObjRNTipoProducto.Eliminar(ObjTipoProducto);

                            if (Rpta)
                            {
                                this.MensajeOk("Se elimino correctamente");
                                this.cbEliminar.Checked = false;
                            }
                            else
                            {
                                this.MensajeError("No se pudo eliminar porque el Usuario, esta asignado a otras tablas");
                                this.cbEliminar.Checked = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            this.dgvTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(0);
        }
    }
}
