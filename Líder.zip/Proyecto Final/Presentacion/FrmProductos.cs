﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;
using Proyecto1.RN;
using Utilitarios;

namespace Presentacion
{
    public partial class FrmProductos : Form
    {
        public FrmProductos()
        {
            InitializeComponent();
        }

        private void limpiar()
        {
            //this.txbId.Text = "";
            this.txbNombre.Text = "";
            this.txbPrecio.Text = "";
            this.cbTipo.SelectedIndex = 1;
            this.txbCantidad.Text = "";
            
            //this.txbBuscar.Text = "Todos";

            //this.cbEliminar.Checked = false;
            this.btnGuardar.Enabled = false;
            //this.btnEliminar.Enabled = false;
            //this.btnImprimir.Enabled = false;
            this.btnGuardar.Text = "Guardar";
        }

        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void CargarComboTipo()
        {
            RNTipoProducto ObjRNTipoProducto = new RNTipoProducto();
            this.cbTipo.DataSource = ObjRNTipoProducto.TraerTipoProducto(0);
            this.cbTipo.DisplayMember = "tipo";
            this.cbTipo.ValueMember = "idTipoProducto";
        }

        private void CargarComboProducto()
        {
            RNProducto ObjRNProducto = new RNProducto();
            this.cbProducto.DataSource = ObjRNProducto.TraerProductoParaComboBox();
            this.cbProducto.DisplayMember = "nombre";
            this.cbProducto.ValueMember = "idProducto";
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            RNProducto ObjRNProducto = new RNProducto();
            Producto ObjProducto = new Producto();
            Inventario ObjInventario = new Inventario();
            

            if(this.btnGuardar.Text == "Guardar")
            {
                ObjProducto.idProducto = ObjRNProducto.GenerarId();
                ObjProducto.nombre = this.txbNombre.Text;
                ObjProducto.precio = Convert.ToInt32(this.txbPrecio.Text);
                ObjProducto.idTipoProd = int.Parse(this.cbTipo.SelectedValue.ToString());

                ObjInventario.idInventario = ObjProducto.idProducto;
                ObjInventario.idProducto = ObjProducto.idProducto;
                ObjInventario.cantidad = Convert.ToInt32(this.txbCantidad.Text);

                if (ObjRNProducto.Insertar(ObjProducto, ObjInventario))
                {
                    MessageBox.Show("Producto insertado con exito!");
                    this.txbCodigo.Text = ObjProducto.idProducto.ToString();
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(ObjProducto.idProducto);
                    Utilitarios.Utilitarios.id = ObjProducto.idProducto;
                }
                else
                {
                    MessageBox.Show("Error en el registro de Usuario");
                }

            }
            else
            {
                ObjProducto.idProducto = Convert.ToInt32(this.txbCodigo.Text);
                ObjProducto.nombre = this.txbNombre.Text;
                ObjProducto.precio = Convert.ToDecimal(this.txbPrecio.Text);
                ObjProducto.idTipoProd = int.Parse(this.cbTipo.SelectedValue.ToString());

                ObjInventario.idInventario = ObjProducto.idProducto;
                ObjInventario.idProducto = ObjProducto.idProducto;
                ObjInventario.cantidad = Convert.ToInt32(this.txbCantidad.Text);

                if (ObjRNProducto.Modificar(ObjProducto, ObjInventario))
                {
                    MessageBox.Show("Datos actualizados con exito!");
                    this.txbCodigo.Text = ObjProducto.idProducto.ToString();
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(ObjProducto.idProducto);
                    Utilitarios.Utilitarios.id = ObjProducto.idProducto;
                }
                else
                {
                    MessageBox.Show("Error en la actualizacion de los datos");
                }
            }
            this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(Convert.ToInt32(this.txbCodigo.Text));
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            this.CargarComboTipo();
            this.CargarComboProducto();
        }

        private void cbEliminar_CheckedChanged(object sender, EventArgs e)
        {
            RNProducto ObjRNProducto = new RNProducto();
            if (cbEliminar.Checked)
            {
                this.dgvProductos.Columns[0].Visible = true;
                this.btnEliminar.Enabled = true;
            }
            else
            {
                this.dgvProductos.Columns[0].Visible = false;
                this.btnEliminar.Enabled = false;
            }
            this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(0);
        }

        private void txbBuscar_TextChanged(object sender, EventArgs e)
        {
            RNProducto ObjRNProducto = new RNProducto();
            if (this.txbBuscar.Text == "Todos")
            {
                this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(0);
            }
            else
            {
                int id;
                if (int.TryParse(this.txbBuscar.Text, out id))
                {
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(id);
                }
                else
                {
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductosPorNombre(this.txbBuscar.Text);
                }

            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.txbCodigo.Text = "0";
            RNProducto ObjRNProducto = new RNProducto();
            if (this.txbBuscar.Text == "Todos")
            {
                this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(0);
            }
            else
            {
                int id;
                if (int.TryParse(this.txbBuscar.Text, out id))
                {
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(id);
                }
                else
                {
                    this.dgvProductos.DataSource = ObjRNProducto.TraerProductosPorNombre(this.txbBuscar.Text);
                }

            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if(this.txbCodigo.Text == "0")
            Utilitarios.Utilitarios.NroReporte = 3;
            FrmReportes ObjFrmReporte = new FrmReportes();
            ObjFrmReporte.Show();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            RNProducto ObjRNProducto = new RNProducto();
            Producto ObjProducto = new Producto();
            Inventario ObjInventario = new Inventario();
            

            try
            {
                DialogResult Opcion;
                Opcion = MessageBox.Show("Está seguro que desea eliminar estos registros?", "Productos", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (Opcion == DialogResult.OK)
                {
                    Boolean Rpta = false;
                    foreach (DataGridViewRow row in dgvProductos.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            ObjProducto.idProducto = Convert.ToInt32(row.Cells[1].Value);
                            ObjInventario.idInventario = Convert.ToInt32(row.Cells[1].Value);

                            Rpta = ObjRNProducto.Eliminar(ObjProducto, ObjInventario);

                            if (Rpta)
                            {
                                this.MensajeOk("Se elimino correctamente");
                                this.cbEliminar.Checked = false;
                            }
                            else
                            {
                                this.MensajeError("No se pudo eliminar porque el Usuario, esta asignado a otras tablas");
                                this.cbEliminar.Checked = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(0);
        }

        private void dgvProductos_DoubleClick(object sender, EventArgs e)
        {
            this.txbCodigo.Text = Convert.ToString(this.dgvProductos.CurrentRow.Cells[1].Value);
            this.txbNombre.Text = Convert.ToString(this.dgvProductos.CurrentRow.Cells[2].Value);
            this.txbPrecio.Text = Convert.ToString(this.dgvProductos.CurrentRow.Cells[3].Value);
            this.cbTipo.SelectedValue = 1;
            this.txbCantidad.Text = Convert.ToString(this.dgvProductos.CurrentRow.Cells[5].Value);
            this.btnGuardar.Text = "Actualizar";
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProductos.Rows[e.RowIndex];
                int id = Convert.ToInt32(row.Cells[1].Value);
                Utilitarios.Utilitarios.id = id;
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            RNProducto ObjRNProducto = new RNProducto();
            Inventario ObjInventario = new Inventario();

            ObjInventario.idInventario = int.Parse(this.cbProducto.SelectedValue.ToString());
            ObjInventario.idProducto = int.Parse(this.cbProducto.SelectedValue.ToString());
            ObjInventario.cantidad = Convert.ToInt32(this.nudCantidad.Value);
                

            if (ObjRNProducto.InsertarStock(ObjInventario))
            {
                MessageBox.Show("Stock agregado con éxito!");
                this.nudCantidad.Value = 0;
            }
            else
            {
                MessageBox.Show("Error al agregar stock");
            }

            this.dgvProductos.DataSource = ObjRNProducto.TraerProductos(0);
        }

        private void btnAgregarStock_Click(object sender, EventArgs e)
        {
            this.lblCodigo.Visible = false;
            this.lblNombre.Visible = false;
            this.lblPrecio.Visible = false;
            this.lblTipo.Visible = false;
            this.lblCantidad.Visible = false;
            this.txbCodigo.Visible = false;
            this.txbNombre.Visible = false;
            this.txbPrecio.Visible = false;
            this.cbTipo.Visible = false;
            this.txbCantidad.Visible = false;
            this.btnGuardar.Visible = false;

            this.lblProductoAgregar.Visible = true;
            this.lblCantidadAgregar.Visible = true;
            this.btnAgregar.Visible = true;
            this.cbProducto.Visible = true;
            this.nudCantidad.Visible = true;
        }

        private void btnNuevoProducto_Click(object sender, EventArgs e)
        {
            this.lblCodigo.Visible = true;
            this.lblNombre.Visible = true;
            this.lblPrecio.Visible = true;
            this.lblTipo.Visible = true;
            this.lblCantidad.Visible = true;
            this.txbCodigo.Visible = true;
            this.txbNombre.Visible = true;
            this.txbPrecio.Visible = true;
            this.cbTipo.Visible = true;
            this.txbCantidad.Visible = true;
            this.btnGuardar.Visible = true;

            this.lblProductoAgregar.Visible = false;
            this.lblCantidadAgregar.Visible = false;
            this.btnAgregar.Visible = false;
            this.cbProducto.Visible = false;
            this.nudCantidad.Visible = false;
        }
    }
}
