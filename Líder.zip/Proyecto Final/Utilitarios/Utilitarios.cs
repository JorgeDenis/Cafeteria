﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Utilitarios
{
    public static class Utilitarios
    {
        public static Int64 id=0;
        public static Int32 NroReporte;
    }
}
