﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace Proyecto1.RN
{
    public class RNProducto : Contexto
    {
        CAFETERIA2023Entities Esquema;
        public RNProducto()
        {
            Esquema = this.TraerContexto();
        }
        public int GenerarId()
        {
            try
            {
                return (from e in Esquema.Producto select e.idProducto).Max() + 1;
            }
            catch (Exception e)
            {
                return 1;
            }
        }

        public bool Insertar(Producto objProducto, Inventario ObjInventario)
        {
            try
            {
                Esquema.Producto.Add(objProducto);
                Esquema.Inventario.Add(ObjInventario);
                Esquema.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool InsertarStock(Inventario ObjInventario)
        {
            Inventario ObjInventarioAux = Esquema.Inventario.FirstOrDefault(a => a.idInventario == ObjInventario.idInventario);
            int cantidad = Convert.ToInt32(ObjInventarioAux.cantidad) + Convert.ToInt32(ObjInventario.cantidad);
            ObjInventarioAux.idInventario = ObjInventario.idInventario;
            ObjInventarioAux.idProducto = ObjInventario.idProducto;
            ObjInventarioAux.cantidad = cantidad;
            return Esquema.SaveChanges() > 0;
        }

        public bool Modificar(Producto objProducto, Inventario ObjInventario)
        {
            Producto objProductoAux = Esquema.Producto.FirstOrDefault(a => a.idProducto == objProducto.idProducto);
            Inventario ObjInventarioAux = Esquema.Inventario.FirstOrDefault(a => a.idInventario == ObjInventario.idInventario);

            objProductoAux.idProducto = objProducto.idProducto;
            objProductoAux.nombre = objProducto.nombre;
            objProductoAux.precio = objProducto.precio;
            objProductoAux.idTipoProd = objProducto.idTipoProd;

            ObjInventarioAux.idInventario = ObjInventario.idInventario;
            ObjInventarioAux.idProducto = ObjInventario.idProducto;
            ObjInventarioAux.cantidad = ObjInventario.cantidad;

            return Esquema.SaveChanges() > 0;
        }

        public bool Eliminar(Producto objProducto, Inventario ObjInventario)
        {
            try
            {
                Producto objProductoAux = Esquema.Producto.FirstOrDefault(a => a.idProducto == objProducto.idProducto);
                Inventario ObjInventarioAux = Esquema.Inventario.FirstOrDefault(a => a.idInventario == ObjInventario.idInventario);

                // Verificar si el producto no está asociado a ningún inventario
                if (objProductoAux.Factura.Count == 0)
                {
                    Esquema.Inventario.Remove(ObjInventarioAux);
                    Esquema.Producto.Remove(objProductoAux);
                    return Esquema.SaveChanges() > 0;
                }
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public List<VistaProductos> TraerProductos(int id)
        {
            if (id == 0)
            {
                return (from e in Esquema.VistaProductos select e).ToList();
            }
            else
            {
                return (from e in Esquema.VistaProductos where e.ID == id select e).ToList();
            }
        }

        public List<VistaProductos> TraerProductosPorNombre(string nombre)
        {
            return (from e in Esquema.VistaProductos where e.Nombre.ToUpper().StartsWith(nombre.ToUpper()) select e).ToList();
        }

        public List<VistaProductos> TraerProductosPorTipo(string tipo)
        {
            return (from e in Esquema.VistaProductos where e.Tipo == tipo select e).ToList();
        }

        public List<Producto> TraerProductoParaComboBox()
        {
            return (from e in Esquema.Producto select e).ToList();
        }
        public List<Producto> TraerProductoParaComboBox2(int id)
        {
            if(id == 0)
            {
                return (from e in Esquema.Producto select e).ToList();
            }
            else
            {
                return (from e in Esquema.Producto where e.idProducto == id select e).ToList();
            }
        }
    }
}
