﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Presentacion
{
    public partial class FrmTopClientes : Form
    {
        SqlConnection Conexion = new SqlConnection(@"Data Source=LIDERTECH\SQLEXPRESS;Initial Catalog=CAFETERIA2023;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
        SqlCommand cmd;
        SqlDataReader dr;
        public FrmTopClientes()
        {
            InitializeComponent();
        }

        ArrayList Clientes = new ArrayList();
        ArrayList Monto = new ArrayList();

        private void GrafCategorias()
        {
            cmd = new SqlCommand("TopClientes", Conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            Conexion.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Clientes.Add(dr.GetString(0));
                Monto.Add(Math.Round(Convert.ToSingle(dr.GetValue(1)), 2));
            }
            chartClientes.Series[0].Points.DataBindXY(Clientes, Monto);
            dr.Close();
            Conexion.Close();

        }

        private void FrmTopClientes_Load(object sender, EventArgs e)
        {
            GrafCategorias();
        }
    }
}
