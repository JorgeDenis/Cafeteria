﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Presentacion
{
    public partial class FrmTopVendedores : Form
    {
        SqlConnection Conexion = new SqlConnection(@"Data Source=C3PO;Initial Catalog=CAFETERIA2023;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
        SqlCommand cmd;
        SqlDataReader dr;
        public FrmTopVendedores()
        {
            InitializeComponent();
        }

        ArrayList Vendedores = new ArrayList();
        ArrayList Monto = new ArrayList();


        private void GrafCategorias()
        {
            cmd = new SqlCommand("TopVendedores", Conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            Conexion.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Vendedores.Add(dr.GetString(0));
                Monto.Add(Math.Round(Convert.ToSingle(dr.GetValue(1)), 2));
            }
            chartVendedores.Series[0].Points.DataBindXY(Vendedores, Monto);
            dr.Close();
            Conexion.Close();

        }

        private void FrmTopVendedores_Load(object sender, EventArgs e)
        {
            GrafCategorias();
        }
    }
}
