﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Presentacion
{
    public partial class FrmDashboard : Form
    {
        SqlConnection Conexion = new SqlConnection(@"Data Source=C3PO;Initial Catalog=CAFETERIA2023;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
        SqlCommand cmd;
        SqlDataReader dr;
        public FrmDashboard()
        {
            InitializeComponent();
        }

        private void FrmDashboard_Load(object sender, EventArgs e)
        {
            GrafCategorias();
        }
        ArrayList Tipo = new ArrayList();
        ArrayList CantProd = new ArrayList();


        private void GrafCategorias()
        {
            cmd = new SqlCommand("ProdPreferidos", Conexion);
            cmd.CommandType = CommandType.StoredProcedure;
            Conexion.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Tipo.Add(dr.GetString(0));
                CantProd.Add(dr.GetInt32(1));
            }
            chartProdCat.Series[0].Points.DataBindXY(Tipo, CantProd);
            dr.Close();
            Conexion.Close();
            
        }
    }
}
